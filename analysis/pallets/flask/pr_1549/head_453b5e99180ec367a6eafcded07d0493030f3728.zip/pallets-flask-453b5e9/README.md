## Flask

web development, one drop at a time

### What is Flask?

Flask is a microframework for Python based on Werkzeug
and Jinja2.  It's intended for getting started very quickly
and was developed with best intentions in mind.

### Is it ready?

  It's still not 1.0 but it's shaping up nicely and is
  already widely used.  Consider the API to slightly
  improve over time but we don't plan on breaking it.

### What do I need?

  All dependencies are installed by using `pip install Flask`.
  We encourage you to use a virtualenv. Check the docs for
  complete installation and usage instructions.

### Where are the docs?

  Go to http://flask.pocoo.org/docs/ for a prebuilt version
  of the current documentation.  Otherwise build them yourself
  from the sphinx sources in the docs folder.

### Where are the tests?

  Good that you're asking.  The tests are in the
  tests/ folder.  To run the tests use the
  `py.test` testing tool:

    $ py.test

### Where can I get help?

  Either use the #pocoo IRC channel on irc.freenode.net or
  ask on the mailinglist: http://flask.pocoo.org/mailinglist/

  See http://flask.pocoo.org/community/ for more resources.


