import abc


class BaseHandler(metaclass=abc.ABCMeta):
    """Abstract Base Class for an internet media type handler"""

    @abc.abstractmethod  # pragma: no cover
    def serialize(self, media, content_type):
        """Serialize the media object on a :any:`falcon.Response`

        Args:
            media (object): A serializable object.
            content_type (str): Type of response content.

        Returns:
            bytes: The resulting serialized bytes from the input object.
        """

    @abc.abstractmethod  # pragma: no cover
    def deserialize(self, stream, content_type, content_length):
        """Deserialize the :any:`falcon.Request` body.

        Args:
            stream (object): Input data to deserialize.
            content_type (str): Type of request content.
            content_length (int): Length of request content.

        Returns:
            object: A deserialized object.
        """

    exhaust_stream = False
    """Whether to exhaust the WSGI input stream upon finishing deserialization.

    Exhausting the stream may be useful for handlers that do not necessarily
    consume the whole stream, but the deserialized media object is complete and
    does not involve further streaming.
    """
